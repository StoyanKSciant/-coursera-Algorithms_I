import java.util.Iterator;
import java.util.NoSuchElementException;

public class Deque<Item> implements Iterable<Item> {

	private int size;			// number of items on the deque
	private Node<Item> first;	// link to most recently added node
	private Node<Item> last;	// link to least recently added node

	public Deque() { // construct an empty deque
		first = null;
		last = null;
		size = 0;
	}

	private class Node<Item> {
		private Item item;
		private Node<Item> next;
		private Node<Item> prev;
	}

	private class DequeIterator implements Iterator<Item> {
		private Node<Item> current = first;
		
		@Override
		public boolean hasNext() {
			return current != null;
		}
		
		@Override
		public void remove() {	// doesn't support remove()
			throw new UnsupportedOperationException("remove() method is not supported");
		}

		@Override
		public Item next() {
			if (!hasNext()) {
				throw new NoSuchElementException("There are no more items left");
			}
			Item item = current.item;
			current = current.next;
			return item;
		}
	}
	
	public boolean isEmpty() { // is the deque empty?
		return size == 0;
	}

	public int size() { // return the number of items on the deque
		return size;
	}

	public void addFirst(Item item) { // add the item to the front
		if (item == null) {
			throw new IllegalArgumentException("Can't add unexisting item");
		}
		if (isEmpty()) {
			first = new Node<Item>();
			first.item = item;
			last = first;
		} else {
			Node<Item> oldfirst = first;
			first = new Node<Item>();
			first.item = item;
			first.next = oldfirst;
			oldfirst.prev = first;
		}
		size++;
	}

	public void addLast(Item item) {	// add the item to the end
		if (item == null) {
			throw new IllegalArgumentException("Can't add unexisting item");
		}
		Node<Item> newLast = new Node<Item>();
		newLast.item = item;
		if (last != null) {
			newLast.prev = last;
			last.next = newLast;
		}
		last = newLast;
		if (first == null) {
			first = last;
		}
		size++;
	}
	
	public Item removeFirst() { 		// remove and return the item from the front
		if (isEmpty()) {
			throw new NoSuchElementException("Can't remove item form empty queue");
		}
		Item remFirstItem = first.item;
		if(size == 1) {
			last = null;
			first = null;
		} else {
			first.next.prev = null; 	// there are no nodes after first so first.next = null	
			first = first.next;			// point to second item as the new first
		}
		size--;
		return remFirstItem;
	}

	public Item removeLast() { // remove and return the item from the end
		if (isEmpty()) {
			throw new NoSuchElementException("Can't remove item form empty queue");
		}
		Item remLastItem = last.item;
		if(last.prev == null) {
			last = null;
			first = null;
		} else {
			last.prev.next = null; 	// there are no nodes after tail so tail.previous = null
			last = last.prev; 		// point to second-to-last as the new tail Node
		}
		size--;
		return remLastItem	;
	}

	@Override
	public Iterator<Item> iterator() { // return an iterator over items in order from front to end
		return new DequeIterator();
	}
}