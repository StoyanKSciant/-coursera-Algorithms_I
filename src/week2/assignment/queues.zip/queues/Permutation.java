import edu.princeton.cs.algs4.StdIn;
import edu.princeton.cs.algs4.StdOut;

public class Permutation {

	public static void main(String[] args) {

		// takes an integer k as a command-line argument
		int k = Integer.parseInt(args[0]);
		RandomizedQueue<String> rq = new RandomizedQueue<>();

		while (!StdIn.isEmpty()) {
			// reads in a sequence of strings from standard input
			rq.enqueue(StdIn.readString());
		}

		for (int i = 0; i < k; i++) {
			StdOut.println(rq.dequeue());
		}
	}
}