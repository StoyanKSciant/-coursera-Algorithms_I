import java.util.Iterator;
import java.util.NoSuchElementException;
import edu.princeton.cs.algs4.StdRandom;

public class RandomizedQueue<Item> implements Iterable<Item> {

	private Item[] queue; 				// queue elements
	private int first; 					// index of first element of queue
	private int last; 					// index of next available slot
	private int size; 					// number of items on the queue

	public RandomizedQueue() { 			// construct an empty randomized queue
		queue = (Item[]) new Object[2];
		first = 0;						// used as dummy node
		last = 0;						// used as dummy node
		size = 0;
	}
	

	private class RandomizedQueueIterator implements Iterator<Item> {
		private int current;
		private int initialSize;
	    private int[] order;
	    
	    public RandomizedQueueIterator() {
            initialSize = size;
            current = 0;
            order = new int[size];
            for (int i = 0; i < size; i++) {
                order[i] = i;
            }
            StdRandom.shuffle(order);	// order keys at random
        }
	    
		@Override
		public boolean hasNext() {
			return current < size || size == 0;
		}

		@Override
		public void remove() { 			// doesn't support remove()
			throw new UnsupportedOperationException("remove() method is not supported");
		}

		@Override
		public Item next() {
            if (!hasNext()) {
                throw new java.util.NoSuchElementException();
            }
            Item item = queue[order[current]];
            if (size() != initialSize) {
                throw new java.util.ConcurrentModificationException();
            }
            current++;
            return item;
		}
	}
	
	public boolean isEmpty() { 			// is the randomized queue empty?
		return size == 0;
	}

	public int size() { 				// return the number of items on the randomized queue
		return size;
	}

	private void resizeQueue(int capacity) { // resize the underlying array
		if (capacity >= size) {
			Item[] temp = (Item[]) new Object[capacity];
			for (int i = 0; i < size; i++) {
				temp[i] = queue[(first + i) % queue.length];
			}
			queue = temp;
			first = 0;
			last = size;
		}
	}

	public void enqueue(Item item) {	// add the item
		if (item == null) {
			throw new IllegalArgumentException("can't enqueue unexisting item");
		}
		if (size == queue.length) {		// double size of array if necessary
			resizeQueue(2 * queue.length);	
		}
		queue[last++] = item; 			// add item
		if (last == queue.length) {
			last = 0; 				  	// wrap-around
		}
		size++;							// increase size
	}

	public Item dequeue() { 			// remove and return a random item
		if (isEmpty()) {
			throw new NoSuchElementException("queue is empty - nothing to dequeue");
		}
		
		int randomIndex = StdRandom.uniform(size); //dequeue operation must be at random choosing
		Item item = queue[randomIndex];
		queue[randomIndex] = queue[first]; // to avoid loitering
		queue[first] = null;
		size--;
		first++;
		if (first == queue.length) {
			first = 0;          		 // wrap-around
		}
		if (size > 0 && size == queue.length / 4) // shrink size of array if necessary
			resizeQueue(queue.length / 2);
		return item;
	}

	public Item sample() { 				// return a random item (but do not remove it)
		if (size == 0) {
			throw new NoSuchElementException("queue is empty - nothing to dequeue");
		}
		return queue[StdRandom.uniform(0, size)];
	}

	@Override
	public Iterator<Item> iterator() { // return an independent iterator over items in random order
		return new RandomizedQueueIterator();
	}
}